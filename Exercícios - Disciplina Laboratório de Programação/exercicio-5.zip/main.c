/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*Faça um programa para converter uma letra maiúscula em letra minúscula. Use a tabela ASCII e 
imprima a mensagem “Erro\n” se o usuário não digitar uma letra maiúscula no intervalo A-Z. (4 pontos)*/
#include <stdio.h>

int main()
{
    char a;
    scanf("%c", &a);
    
    if (a < 65 || a > 90){
        printf("Erro\n");
    } else{
        a = a + 32;
        printf("%c", a);
    }

    return 0;
}
