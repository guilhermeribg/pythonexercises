/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Uma empresa contrata um encanador a R$ 30,00 por dia. 
//Crie um programa que solicite o número de dias trabalhados pelo encanador e 
//imprima a quantia líquida (com 2 casas decimais) que deverá ser paga, 
//sabendo-se que são descontados 7.5% para imposto de renda. (4 pontos)
#include <stdio.h>

int main()
{
    double salarioBruto, diasTrab;
    scanf("%lf", &diasTrab);
    salarioBruto = diasTrab*30;
    double salarioLiq = salarioBruto - (salarioBruto* 0.075);
    printf("%.2lf", salarioLiq);

    return 0;
}
