/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    float altura, raio;
    scanf("%f %f", &altura, &raio);
    
    if(altura < 0 || raio < 0){
        printf("Erro\n");
    } else {
    
    float pi = 3.141592;
    float volume = pi * pow(raio,2) * altura;
    //volume = pi * raio^2 * altura
    //pi = 3.141592
    printf("%.6f", volume);
    }    

    return 0;
}
