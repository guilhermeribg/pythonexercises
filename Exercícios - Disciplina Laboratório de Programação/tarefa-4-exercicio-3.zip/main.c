/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    struct cordPolar {
        float r, a;
    };
    
    struct cordCart {
        float x, y;
    };
    
    struct cordPolar coordenada;
    struct cordCart cartesiano;
    
    scanf("%f %f", &coordenada.r, &coordenada.a);
    
    cartesiano.x = coordenada.r*cos(coordenada.a);
    cartesiano.y = coordenada.r*sin(coordenada.a);
    printf("%.2f %.2f\n", cartesiano.x, cartesiano.y);
    return 0;
}
