/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
    char entrada[256];
    fgets(entrada, 256, stdin);
    for (int i = 0; entrada[i] != '\0'; i++){
        if ((entrada[i] >= 65 && entrada[i] <= 87) || (entrada[i] >= 97 && entrada[i] <= 119) ){
            entrada[i]+= 3;
        }else if (entrada [i] >= 88 && entrada[i] <= 90){
            entrada[i]-= 23;
        } else if (entrada [i] >= 120 && entrada[i] <= 122){
            entrada[i]-= 23;
        } 
    }
        printf("%s\n", entrada);
   

    return 0;
}
