/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main(){
    
    FILE *fp;
    fp = fopen("arq.txt", "r");
    if(fp == NULL){
        printf("Erro na abertura do arquivo");
        exit(1);
    }
    
    char entrada[256];
    fread(entrada, sizeof(char), 256,fp);
    for (int i = 0; entrada[i] != '\0'; i++){
        if ((entrada[i] >= 65 && entrada[i] <= 87) || (entrada[i] >= 97 && entrada[i] <= 119) ){
            entrada[i]+= 3;
        }else if (entrada [i] >= 88 && entrada[i] <= 90){
            entrada[i]-= 23;
        } else if (entrada [i] >= 120 && entrada[i] <= 122){
            entrada[i]-= 23;
        } 
    }
    printf("%s\n", entrada);
   
    fclose(fp);
    return 0;
}
