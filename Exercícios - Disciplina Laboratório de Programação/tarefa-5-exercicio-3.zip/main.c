/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>


int expoente (int x, int n){
    if (n==0){
        return 1;
    }else{
        return x*expoente(x, n-1);
    }
}

int main()
{
    int x, n;
    scanf("%d %d", &x, &n);
    if ((n < 0) || (x < 0)){
        printf("Erro\n");
    }else{
        printf("%d\n", expoente(x,n));
    }
    return 0;
}
