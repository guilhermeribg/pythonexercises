/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Leia uma velocidade em m/s (metros por segundo) e apresente-a convertida em km/h (quilômetros por hora). 
//A fórmula de conversão é: K = M * 3.6, sendo K a velocidade em km/h e M em m/s. (4 pontos)
#include <stdio.h>

int main()
{
    double velocidade;
    scanf("%lf", &velocidade);
    double K = velocidade * 3.6;
    printf("%.6lf", K);

    return 0;
}
