/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int M1[n][n],M2[n][n], M3[n][n], i, j;
     
    /*CRIANDO MATRIZES ------------------------------------------------*/
    for (i = 0; i < n; i++){
        for(j = 0; j< n; j++){
            scanf("%d", &M1[i][j]);
        }
    }
    
    for (i = 0; i < n; i++){
        for(j = 0; j< n; j++){
            scanf("%d", &M2[i][j]);
        }
    }    
    
    /*COMPARANDO VALORES E ATRIBUINDO A M3------------------------------*/
    
    for (i=0; i< n; i++){
        for (j=0; j<n; j++){
            if (M1[i][j] > M2[i][j]){
                M3[i][j] = M1[i][j];
            } else{
                M3[i][j] = M2[i][j];
            }
        }
    }
    
    /*IMPRIMINDO M3----------------------------------------------------*/
    
    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            printf("%d ", M3[i][j]);
        }
        printf("\n");
    }
    
    
    return 0;
}
