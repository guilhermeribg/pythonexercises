/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

void troca_char(int n, char entrada[256]){
    for (int i = 0; entrada[i] != '\0'; i++){
        if ((entrada[i] >= 65 && entrada[i] <= 87) || (entrada[i] >= 97 && entrada[i] <= 119) ){
            entrada[i]+= n;
        }else if (entrada[i] >= 88 && entrada[i] <= 90){
            entrada[i]-= 26 + n;
        } else if (entrada[i] >= 120 && entrada[i] <= 122){
            entrada[i]-= 26 + n;
        } 
    }
    printf("%s\n", entrada);
}

int main()
{
    int n;
    char frase[256];
    scanf("%d\n", &n);
    fgets(frase, 256, stdin);

    troca_char(n, frase);

    
    return 0;
}

