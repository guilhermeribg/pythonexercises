/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char frase[256], palavra[8], testa[8];
    fgets(frase, 256, stdin);
    fgets(palavra, 8, stdin);
    
    int i, j, k, contador;
    
    contador = 0;
    for (i=0; frase[i] != '\0'; i++){   //for até quando durar a frase
        k = i;
        for (j = 0; palavra[j] != '\0'; j++){ //FOR ATÉ QUANDO DURAR A PALAVRA, gravo as 3 palavras em testa para verificar se é igual a palavra, se não for reseta e passa pra proxima letra.
            testa[j] = frase[k];
            k++;
            if (strcmp(testa, palavra) == 0){
                contador++;
            }
        }

    }
    
    printf("%d", contador);
    return 0;
}

/*MARA VIU UMA ARARA
ARA
3
strcmp(s1, s2)

*/

